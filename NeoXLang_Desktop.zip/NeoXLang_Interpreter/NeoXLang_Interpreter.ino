// ============================================================
//  NeoXLang Interpreter - COMPLETE FULL FEATURE
//  With Robust Communication (Checksums, Retries, Error Handling)
//  ALL Opcodes Included - NOTHING REMOVED
// ============================================================

#include <EEPROM.h>

#define MAX_PROGRAM   512
#define MAX_VARS       16
#define MAX_ARRAYS      2
#define ARRAY_MAX      16
#define STACK_SIZE      8
#define CALL_DEPTH      4

// EEPROM layout
#define EEPROM_LEN_ADDR    0
#define EEPROM_MAGIC_ADDR  2
#define EEPROM_CODE_ADDR   4
#define EEPROM_MAGIC_VAL   0x4E58

// Protocol constants
#define SYNC_BYTE1        0xAA
#define SYNC_BYTE2        0x55
#define END_MARKER        0xCC
#define ACK_OK            0x4F
#define ACK_ERROR         0x45
#define ACK_READY         0x52

typedef int16_t vm_int;

// ============================================================
// ALL OPCODES - FULL SET
// ============================================================
#define OP_PROGRAM_START  0x00
#define OP_PROGRAM_END    0x01
#define OP_DECLARE_VAR    0x10
#define OP_ASSIGN_VAR     0x11
#define OP_LOAD           0x12
#define OP_STORE          0x13
#define OP_LOAD_CONST     0x14
#define OP_LOAD_STRING    0x15
#define OP_LOAD_DEFAULT   0x16
#define OP_INCREMENT      0x35
#define OP_DECREMENT      0x36
#define OP_CREATE_ARRAY   0x20
#define OP_ARRAY_STORE    0x21
#define OP_ARRAY_LOAD     0x22
#define OP_CHECK_BOUNDS   0x23
#define OP_DECLARE_ARRAY  0x24
#define OP_ADD            0x30
#define OP_SUBTRACT       0x31
#define OP_MULTIPLY       0x32
#define OP_DIVIDE         0x33
#define OP_MODULO         0x34
#define OP_EQUALS         0x40
#define OP_NOT_EQUALS     0x41
#define OP_LESS_THAN      0x42
#define OP_GREATER_THAN   0x43
#define OP_LESS_EQUAL     0x44
#define OP_GREATER_EQUAL  0x45
#define OP_LOGICAL_AND    0x50
#define OP_LOGICAL_OR     0x51
#define OP_BIT_AND        0x52
#define OP_BIT_OR         0x53
#define OP_BIT_XOR        0x54
#define OP_BIT_NOT        0x55
#define OP_JUMP           0x60
#define OP_JUMP_IF_FALSE  0x61
#define OP_JUMP_IF_TRUE   0x62
#define OP_LABEL          0x63
#define OP_CALL           0x64
#define OP_RETURN         0x65
#define OP_RETURN_VALUE   0x66
#define OP_FUNCTION_START 0x70
#define OP_FUNCTION_END   0x71
#define OP_PIN_MODE       0xA0
#define OP_DIGITAL_WRITE  0xA1
#define OP_DIGITAL_READ   0xA2
#define OP_ANALOG_READ    0xA3
#define OP_ANALOG_WRITE   0xA4
#define OP_DELAY_MS       0xB0
#define OP_DELAY_US       0xB1
#define OP_GET_MILLIS     0xB2
#define OP_GET_MICROS     0xB3
#define OP_SERIAL_BEGIN   0xC0
#define OP_SERIAL_PRINT   0xC1
#define OP_SERIAL_PRINTLN 0xC2
#define OP_SERIAL_READ    0xC3
#define OP_SERIAL_AVAIL   0xC4
#define OP_BIT_SET        0xE0
#define OP_BIT_CLEAR      0xE1
#define OP_BIT_READ       0xE2
#define OP_BIT_WRITE      0xE3
#define OP_ATTACH_INTERRUPT   0xD0
#define OP_DETACH_INTERRUPT   0xD1
#define OP_INTERRUPT_HANDLER  0xD2
#define OP_END_INTERRUPT      0xD3
#define OP_FOREACH_START      0xF2
#define OP_FOREACH_NEXT       0xF3
#define OP_FOREACH_END        0xF4
#define OP_WHILE_LOOP         0xF0
#define OP_END_WHILE          0xF1
#define OP_JUMP_IF_DONE       0xF5
#define OP_LOOP_START         0xFC
#define OP_LOOP_END           0xFD
#define OP_SETUP_START        0xFE
#define OP_SETUP_END          0xFF

// ============================================================
// VM MEMORY
// ============================================================
uint8_t  program[MAX_PROGRAM];
uint16_t programLen = 0;
vm_int   vars[MAX_VARS];
uint16_t varMask = 0;
vm_int   stk[STACK_SIZE];
int8_t   stkTop = -1;
vm_int   arrays[MAX_ARRAYS][ARRAY_MAX];
uint8_t  arrLen[MAX_ARRAYS];
uint16_t callStk[CALL_DEPTH];
int8_t   callTop = -1;
bool     running = false;

// ============================================================
// STACK HELPERS
// ============================================================
void push(vm_int v) {
  if (stkTop < STACK_SIZE - 1) {
    stk[++stkTop] = v;
  }
}

vm_int pop() {
  if (stkTop >= 0) {
    return stk[stkTop--];
  }
  return 0;
}

// ============================================================
// CHECKSUM CALCULATION
// ============================================================
uint8_t calculateChecksum(uint8_t* data, uint16_t len) {
  uint8_t sum = 0;
  for (uint16_t i = 0; i < len; i++) {
    sum ^= data[i];
  }
  return sum;
}

// ============================================================
// EEPROM STORAGE FUNCTIONS
// ============================================================
void saveToEEPROM() {
  EEPROM.put(EEPROM_MAGIC_ADDR, EEPROM_MAGIC_VAL);
  EEPROM.put(EEPROM_LEN_ADDR, programLen);
  for (uint16_t i = 0; i < programLen; i++) {
    EEPROM.write(EEPROM_CODE_ADDR + i, program[i]);
  }
  Serial.println(F("Program saved to EEPROM"));
}

bool loadFromEEPROM() {
  uint16_t magic;
  EEPROM.get(EEPROM_MAGIC_ADDR, magic);
  if (magic != EEPROM_MAGIC_VAL) {
    return false;
  }
  
  uint16_t savedLen;
  EEPROM.get(EEPROM_LEN_ADDR, savedLen);
  if (savedLen == 0 || savedLen > MAX_PROGRAM) {
    return false;
  }
  
  programLen = savedLen;
  for (uint16_t i = 0; i < programLen; i++) {
    program[i] = EEPROM.read(EEPROM_CODE_ADDR + i);
  }
  return true;
}

// ============================================================
// RESET VM
// ============================================================
void resetVM() {
  running = false;
  stkTop = -1;
  callTop = -1;
  varMask = 0;
  memset(vars, 0, sizeof(vars));
  memset(arrays, 0, sizeof(arrays));
  memset(arrLen, 0, sizeof(arrLen));
}

// ============================================================
// FIND SECTION MARKER
// ============================================================
int findSection(uint8_t marker) {
  for (uint16_t i = 0; i + 2 < programLen; i += 4) {
    if (program[i] == marker) {
      return (int)i;
    }
  }
  return -1;
}

// ============================================================
// EXECUTE INSTRUCTIONS - FULL OPCODE SET
// ============================================================
void execRange(uint16_t startPC, uint16_t endPC) {
  uint16_t pc = startPC;
  
  while (pc < endPC && running) {
    if (Serial.available() && Serial.peek() == SYNC_BYTE1) {
      running = false;
      return;
    }
    
    uint8_t op = program[pc];
    uint8_t p1 = program[pc + 1];
    uint8_t p2 = program[pc + 2];
    pc += 4;

    switch (op) {
      case OP_PROGRAM_START:
      case OP_PROGRAM_END:
      case OP_SETUP_START:
      case OP_SETUP_END:
      case OP_LOOP_START:
      case OP_LOOP_END:
      case OP_FUNCTION_START:
      case OP_FUNCTION_END:
      case OP_LABEL:
      case OP_WHILE_LOOP:
      case OP_END_WHILE:
        break;

      case OP_DECLARE_VAR:
        if (p1 < MAX_VARS) { vars[p1] = 0; varMask |= (1 << p1); }
        break;
        
      case OP_ASSIGN_VAR:
        if (p1 < MAX_VARS) { vars[p1] = (vm_int)p2; }
        break;
        
      case OP_LOAD_CONST:
        push((vm_int)((int16_t)((uint16_t)p1 | ((uint16_t)p2 << 8))));
        break;
        
      case OP_LOAD:
        push(p1 < MAX_VARS ? vars[p1] : 0);
        break;
        
      case OP_STORE:
        if (p1 < MAX_VARS) { vars[p1] = pop(); }
        break;
        
      case OP_LOAD_DEFAULT:
        push(0);
        break;
        
      case OP_INCREMENT:
        if (p1 < MAX_VARS) { vars[p1]++; }
        break;
        
      case OP_DECREMENT:
        if (p1 < MAX_VARS) { vars[p1]--; }
        break;
        
      case OP_LOAD_STRING:
        push((vm_int)p1);
        break;

      case OP_DECLARE_ARRAY:
      case OP_CREATE_ARRAY:
        if (p1 < MAX_ARRAYS) { arrLen[p1] = p2; }
        break;
        
      case OP_ARRAY_STORE: {
        vm_int val = pop();
        uint8_t idx = (uint8_t)pop();
        if (p1 < MAX_ARRAYS && idx < ARRAY_MAX) { arrays[p1][idx] = val; }
        break;
      }
      
      case OP_ARRAY_LOAD: {
        uint8_t idx = (uint8_t)pop();
        if (p1 < MAX_ARRAYS && idx < ARRAY_MAX) { push(arrays[p1][idx]); } else { push(0); }
        break;
      }
      
      case OP_CHECK_BOUNDS:
        break;

      case OP_ADD: { vm_int b = pop(); vm_int a = pop(); push(a + b); } break;
      case OP_SUBTRACT: { vm_int b = pop(); vm_int a = pop(); push(a - b); } break;
      case OP_MULTIPLY: { vm_int b = pop(); vm_int a = pop(); push(a * b); } break;
      case OP_DIVIDE: { vm_int b = pop(); vm_int a = pop(); push(b ? a / b : 0); } break;
      case OP_MODULO: { vm_int b = pop(); vm_int a = pop(); push(b ? a % b : 0); } break;

      case OP_EQUALS: { vm_int b = pop(); vm_int a = pop(); push(a == b); } break;
      case OP_NOT_EQUALS: { vm_int b = pop(); vm_int a = pop(); push(a != b); } break;
      case OP_LESS_THAN: { vm_int b = pop(); vm_int a = pop(); push(a < b); } break;
      case OP_GREATER_THAN: { vm_int b = pop(); vm_int a = pop(); push(a > b); } break;
      case OP_LESS_EQUAL: { vm_int b = pop(); vm_int a = pop(); push(a <= b); } break;
      case OP_GREATER_EQUAL: { vm_int b = pop(); vm_int a = pop(); push(a >= b); } break;

      case OP_LOGICAL_AND: { vm_int b = pop(); vm_int a = pop(); push(a && b); } break;
      case OP_LOGICAL_OR: { vm_int b = pop(); vm_int a = pop(); push(a || b); } break;
      case OP_BIT_AND: { vm_int b = pop(); vm_int a = pop(); push(a & b); } break;
      case OP_BIT_OR: { vm_int b = pop(); vm_int a = pop(); push(a | b); } break;
      case OP_BIT_XOR: { vm_int b = pop(); vm_int a = pop(); push(a ^ b); } break;
      case OP_BIT_NOT: push(~pop()); break;

      case OP_JUMP: pc = (uint16_t)p1 * 4; break;
      case OP_JUMP_IF_FALSE: if (!pop()) { pc = (uint16_t)p1 * 4; } break;
      case OP_JUMP_IF_TRUE: if (pop()) { pc = (uint16_t)p1 * 4; } break;
      case OP_JUMP_IF_DONE: if (pop()) { pc = endPC; } break;
        
      case OP_CALL:
        if (callTop < CALL_DEPTH - 1) { callStk[++callTop] = pc; pc = (uint16_t)p1 * 4; }
        break;
        
      case OP_RETURN:
      case OP_RETURN_VALUE:
        if (callTop >= 0) { pc = callStk[callTop--]; }
        break;

      case OP_PIN_MODE: {
        vm_int mode = pop(); vm_int pin = pop();
        if (mode == 1) { pinMode((uint8_t)pin, OUTPUT); }
        else if (mode == 2) { pinMode((uint8_t)pin, INPUT_PULLUP); }
        else { pinMode((uint8_t)pin, INPUT); }
        break;
      }
      
      case OP_DIGITAL_WRITE: {
        vm_int val = pop(); vm_int pin = pop();
        digitalWrite((uint8_t)pin, val ? HIGH : LOW);
        break;
      }
      
      case OP_DIGITAL_READ: {
        vm_int pin = pop();
        push((vm_int)digitalRead((uint8_t)pin));
        break;
      }
      
      case OP_ANALOG_READ: {
        vm_int pin = pop();
        push((vm_int)analogRead((uint8_t)pin));
        break;
      }
      
      case OP_ANALOG_WRITE: {
        vm_int val = pop(); vm_int pin = pop();
        analogWrite((uint8_t)pin, (uint8_t)val);
        break;
      }

      case OP_DELAY_MS: {
        vm_int ms = pop();
        uint16_t remaining = (uint16_t)ms;
        while (remaining > 0 && running) {
          uint16_t chunk = (remaining > 10) ? 10 : remaining;
          delay(chunk);
          remaining -= chunk;
          if (Serial.available() && Serial.peek() == SYNC_BYTE1) { running = false; return; }
        }
        break;
      }
      
      case OP_DELAY_US: {
        vm_int us = pop();
        delayMicroseconds((uint16_t)us);
        break;
      }
      
      case OP_GET_MILLIS: push((vm_int)(millis() & 0x7FFF)); break;
      case OP_GET_MICROS: push((vm_int)(micros() & 0x7FFF)); break;

      case OP_SERIAL_BEGIN: {
        vm_int baud = pop();
        Serial.begin(baud ? baud : 9600);
        break;
      }
      
      case OP_SERIAL_PRINT: {
        vm_int val = pop();
        Serial.print(val);
        break;
      }
      
      case OP_SERIAL_PRINTLN: {
        vm_int val = pop();
        Serial.println(val);
        break;
      }
      
      case OP_SERIAL_READ: push((vm_int)Serial.read()); break;
      case OP_SERIAL_AVAIL: push((vm_int)Serial.available()); break;

      case OP_BIT_SET: if (p1 < MAX_VARS) { bitSet(vars[p1], p2); } break;
      case OP_BIT_CLEAR: if (p1 < MAX_VARS) { bitClear(vars[p1], p2); } break;
      case OP_BIT_READ: push((vm_int)bitRead(vars[p1], p2)); break;
      case OP_BIT_WRITE: bitWrite(vars[p1], p2, (uint8_t)pop()); break;

      case OP_ATTACH_INTERRUPT:
      case OP_DETACH_INTERRUPT:
      case OP_INTERRUPT_HANDLER:
      case OP_END_INTERRUPT:
        pop(); pop();
        break;

      case OP_FOREACH_START: break;
      case OP_FOREACH_NEXT: push(0); break;
      case OP_FOREACH_END: break;

      default: break;
    }
  }
}

// ============================================================
// ROBUST UPLOAD HANDLER
// ============================================================
void handleUpload() {
  if (!Serial.available()) return;
  
  Serial.write(ACK_READY);
  delay(5);
  
  unsigned long start = millis();
  while (!Serial.available() && (millis() - start) < 500);
  if (!Serial.available()) return;
  if (Serial.read() != SYNC_BYTE1) return;
  
  start = millis();
  while (!Serial.available() && (millis() - start) < 500);
  if (!Serial.available()) return;
  if (Serial.read() != SYNC_BYTE2) {
    Serial.write(ACK_ERROR);
    Serial.println(F("ERR: Bad sync"));
    return;
  }
  
  uint8_t hdr[8];
  for (int i = 0; i < 8; i++) {
    start = millis();
    while (!Serial.available() && (millis() - start) < 500);
    if (!Serial.available()) return;
    hdr[i] = Serial.read();
  }
  
  if (hdr[0] != 0x4E || hdr[1] != 0x58 || hdr[2] != 0x4C || hdr[3] != 0x47) {
    Serial.write(ACK_ERROR);
    Serial.println(F("ERR: Bad magic"));
    return;
  }
  
  uint32_t len = ((uint32_t)hdr[4] << 24) | ((uint32_t)hdr[5] << 16) | 
                 ((uint32_t)hdr[6] << 8) | (uint32_t)hdr[7];
  
  if (len == 0 || len > MAX_PROGRAM) {
    Serial.write(ACK_ERROR);
    Serial.println(F("ERR: Bad length"));
    return;
  }
  
  uint8_t expectedChecksum = hdr[7];
  uint8_t newProgram[MAX_PROGRAM];
  uint16_t newLen = 0;
  
  while (newLen < len) {
    start = millis();
    while (!Serial.available() && (millis() - start) < 500);
    if (!Serial.available()) {
      Serial.write(ACK_ERROR);
      Serial.println(F("ERR: Timeout"));
      return;
    }
    newProgram[newLen++] = Serial.read();
  }
  
  uint8_t actualChecksum = calculateChecksum(newProgram, newLen);
  if (actualChecksum != expectedChecksum) {
    Serial.write(ACK_ERROR);
    Serial.println(F("ERR: Checksum mismatch"));
    return;
  }
  
  start = millis();
  while (!Serial.available() && (millis() - start) < 500);
  if (!Serial.available()) return;
  
  if (Serial.read() != END_MARKER) {
    Serial.write(ACK_ERROR);
    Serial.println(F("ERR: Bad end marker"));
    return;
  }
  
  running = false;
  resetVM();
  programLen = newLen;
  memcpy(program, newProgram, programLen);
  saveToEEPROM();
  
  Serial.write(ACK_OK);
  Serial.print(F(" OK "));
  Serial.print(programLen);
  Serial.println(F(" bytes"));
  
  running = true;
}

// ============================================================
// RUN PROGRAM
// ============================================================
void runProgram() {
  int ss = findSection(OP_SETUP_START);
  int se = findSection(OP_SETUP_END);
  int ls = findSection(OP_LOOP_START);
  int le = findSection(OP_LOOP_END);

  if (ss >= 0 && se > ss) {
    execRange(ss + 4, se);
  }
  
  execRange(0, ls >= 0 ? ls : programLen);

  while (running) {
    if (ls >= 0 && le > ls) {
      execRange(ls + 4, le);
    } else {
      delay(100);
    }
  }
}

// ============================================================
// ARDUINO ENTRY POINTS
// ============================================================
void setup() {
  Serial.begin(115200);
  pinMode(13, OUTPUT);
  Serial.println(F("NeoXLang VM ready - FULL FEATURE with Checksums"));
  
  if (loadFromEEPROM()) {
    Serial.println(F("Loaded saved program from EEPROM"));
    running = true;
  } else {
    Serial.println(F("No program in EEPROM. Ready for upload."));
    for (int i = 0; i < 3; i++) {
      digitalWrite(13, HIGH);
      delay(200);
      digitalWrite(13, LOW);
      delay(200);
    }
  }
}

void loop() {
  if (running) {
    runProgram();
    running = false;
    Serial.println(F("Program finished. Ready for next upload."));
  }
  
  handleUpload();
  delay(10);
}